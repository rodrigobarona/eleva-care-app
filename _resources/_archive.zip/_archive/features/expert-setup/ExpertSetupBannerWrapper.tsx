import { ExpertSetupBanner } from '@/components/features/expert-setup/ExpertSetupBanner';
import { db } from '@/drizzle/db';
import { UsersTable } from '@/drizzle/schema-workos';
import { withAuth } from '@workos-inc/authkit-nextjs';
import { eq } from 'drizzle-orm';

export async function ExpertSetupBannerWrapper() {
  const { user } = await withAuth();

  // If user is not authenticated, don't show anything
  if (!user) return null;

  // Get user from database to check role (WorkOS doesn't have publicMetadata)
  const dbUser = await db.query.UsersTable.findFirst({
    where: eq(UsersTable.workosUserId, user.id),
  });

  if (!dbUser) return null;

  // Check if user has an expert role
  const hasExpertRole =
    dbUser.role === 'expert_community' ||
    dbUser.role === 'expert_top' ||
    dbUser.role === 'expert_lecturer';

  // Only show banner to users with expert roles
  if (!hasExpertRole) return null;

  return <ExpertSetupBanner />;
}
